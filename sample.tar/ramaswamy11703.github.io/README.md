  * [Neeva](https://neeva.co) Co-Founder 
  * [Greylock](https://www.greylock.com/) Venture Partner. 
  * Ex-[Google](https://www.google.com) SVP of Ads 
  * Ex-[BellLabs](https://www.bell-labs.com)

### Musings on tech, privacy, ads, books...
